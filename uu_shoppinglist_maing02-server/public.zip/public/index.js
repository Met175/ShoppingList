/*!  */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g05-elements","uu_plus4u5g02","uu_plus4u5g02-app","uu_plus4u5g02-elements","uu5g05-forms","uu5tilesg02","uu5tilesg02-elements"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("uu5tilesg02"),require("uu5tilesg02-elements")):e.index=t(e[void 0],e.uu5g05,e["uu5g05-elements"],e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"],e["uu5g05-forms"],e.uu5tilesg02,e["uu5tilesg02-elements"])
}(this,(e,t,r,n,u,i,s,o,a)=>(()=>{var l,p,c,d,g={154:(e,t,r)=>{"use strict";r.d(t,{A:()=>i});var n=r(606);const u="UuShoppinglist.",i={TAG:u,
Css:n.Utils.Css.createCssModule(u.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shoppinglist_maing02-hi/uu_shoppinglist_maing02-hi@0.1.0")}},258:(e,t,r)=>{"use strict"
;r.d(t,{A:()=>s});var n=r(606),u=r(154);const i=u.A.TAG+"Core.",s={...u.A,TAG:i,
Css:n.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shoppinglist_maing02-hi/uu_shoppinglist_maing02-hi@0.1.0")}},504:(e,t,r)=>{"use strict"
;r.d(t,{Jd:()=>p,Tu:()=>l,vu:()=>a});var n=r(606),u=r(266);const i=[{id:"123",name:"James"},{id:"234",name:"Amelia"},{id:"345",name:"John"},{id:"456",name:"Chloe"}],[s,o]=n.Utils.Context.create([])
;function a({children:e}){const t=(0,n.useState)(i[0]);return(0,u.jsx)(s.Provider,{value:t,children:e})}function l(){const[e,t]=o();return(0,u.jsx)("select",{value:e.id,
onChange:e=>t(i.find(({id:t})=>t===e.target.value)),children:i.map(({id:e,name:t})=>(0,u.jsx)("option",{value:e,children:t},e))})}function p(){return o()[0]}},600:(e,t,r)=>{"use strict";r.r(t),r.d(t,{
render:()=>v});var n=r(606),u=r(294),i=r.n(u),s=r(410),o=r.n(s),a=r(486),l=r.n(a),p=r(258),c=r(504),d=r(266)
;const g=n.Utils.Component.lazy(()=>r.e(876).then(r.bind(r,876))),m=n.Utils.Component.lazy(()=>r.e(396).then(r.bind(r,396))),f=n.Utils.Component.lazy(()=>r.e(687).then(r.bind(r,687))),h=n.Utils.Component.lazy(()=>r.e(531).then(r.bind(r,531))),_={
"":{redirect:"shoppingList"},detail:e=>(0,d.jsx)(h,{...e}),shoppingList:e=>(0,d.jsx)(f,{...e}),"sys/uuAppWorkspace/initUve":e=>(0,d.jsx)(g,{...e}),controlPanel:e=>(0,d.jsx)(m,{...e}),"*":()=>(0,
d.jsx)(i().Text,{category:"story",segment:"heading",type:"h1",children:"Not Found"})},b=(0,n.createVisualComponent)({uu5Tag:p.A.TAG+"Spa",propTypes:{},defaultProps:{},render:()=>(0,d.jsx)(c.vu,{
children:(0,d.jsx)(o().SpaProvider,{initialLanguageList:["en","cs"],children:(0,d.jsx)(i().ModalBus,{children:(0,d.jsx)(l().Spa,{routeMap:_,displayTop:!1})})})})});if(n.Environment.appVersion="0.1.0",
!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}function v(e){n.Utils.Dom.render((0,
d.jsx)(b,{}),document.getElementById(e))}},533:(e,t,r)=>{
var n=r(28),u="undefined"!=typeof document,i=((n?n.uri:u&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),s="/0.0.0/"
;(i=i.split(/\//).slice(0,-1).join("/")+"/").substr(-s.length)!==s&&(s="/0.x/"),i.substr(-s.length)===s&&(i=i.substr(0,i.length-s.length)+"/0.1.0/"),r.p=i,e.exports=r(600);var o=e.exports
;o&&"object"==typeof o&&("version"in o||Object.defineProperty(o,"version",{configurable:!0,value:"0.1.0"}),"name"in o||Object.defineProperty(o,"name",{configurable:!0,
value:"uu_shoppinglist_maing02-hi".split(/[\/\\]/).pop()}),"namespace"in o||Object.defineProperty(o,"namespace",{configurable:!0,value:"UuShoppinglist"}))},266:(e,t,r)=>{
const n=r(606),u=n._jsxJsxRuntime;if(u)Object.assign(t,u);else{let e=n.Utils.Element.create;t.Fragment=n.Fragment,t.jsx=function(t,r,n){let u=void 0!==r.key?r.key:n;return e(t,u!==r.key?{...r,key:u
}:r)},t.jsxs=function(t,r,n){let{children:u,...i}=r,s=void 0!==r.key?r.key:n;return e(t,s!==r.key?{...i,key:n}:i,...u)}}},28:t=>{"use strict";t.exports=e},606:e=>{"use strict";e.exports=t},294:e=>{
"use strict";e.exports=r},698:e=>{"use strict";e.exports=s},534:e=>{"use strict";e.exports=o},502:e=>{"use strict";e.exports=a},410:e=>{"use strict";e.exports=n},486:e=>{"use strict";e.exports=u},
254:e=>{"use strict";e.exports=i}},m={};function f(e){var t=m[e];if(void 0!==t)return t.exports;var r=m[e]={exports:{}};return g[e](r,r.exports,f),r.exports}return f.m=g,f.n=e=>{
var t=e&&e.__esModule?()=>e.default:()=>e;return f.d(t,{a:t}),t},p=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,f.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e
;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e;if(16&t&&"function"==typeof e.then)return e}var r=Object.create(null);f.r(r);var n={};l=l||[null,p({}),p([]),p(p)]
;for(var u=2&t&&e;"object"==typeof u&&!~l.indexOf(u);u=p(u))Object.getOwnPropertyNames(u).forEach(t=>n[t]=()=>e[t]);return n.default=()=>e,f.d(r,n),r},f.d=(e,t)=>{
for(var r in t)f.o(t,r)&&!f.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},f.f={},f.e=e=>Promise.all(Object.keys(f.f).reduce((t,r)=>(f.f[r](e,t),t),[])),f.u=e=>"chunks/index/"+e+"-"+{
153:"5750a3170585a3e3ea7a",396:"6c9a2e03f6dfaa30743c",531:"2941921c073fbda99879",687:"96a546754d91be499a84",876:"ff8badf9af410e9ebf02"}[e]+".min.js",
f.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),c={},d="[name]_0_1_0:",f.l=(e,t,r,n)=>{if(c[e])c[e].push(t);else{var u,i
;if(void 0!==r)for(var s=document.getElementsByTagName("script"),o=0;o<s.length;o++){var a=s[o];if(a.getAttribute("src")==e||a.getAttribute("data-webpack")==d+r){u=a;break}}u||(i=!0,
(u=document.createElement("script")).charset="utf-8",u.timeout=120,f.nc&&u.setAttribute("nonce",f.nc),u.setAttribute("data-webpack",d+r),u.src=e,
0!==u.src.indexOf(window.location.origin+"/")&&(u.crossOrigin="anonymous")),c[e]=[t];var l=(t,r)=>{u.onerror=u.onload=null,clearTimeout(p);var n=c[e];if(delete c[e],
u.parentNode&&u.parentNode.removeChild(u),n&&n.forEach(e=>e(r)),t)return t(r)},p=setTimeout(l.bind(null,void 0,{type:"timeout",target:u}),12e4);u.onerror=l.bind(null,u.onerror),
u.onload=l.bind(null,u.onload),i&&document.head.appendChild(u)}},f.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
Object.defineProperty(e,"__esModule",{value:!0})},f.p="",(()=>{var e={57:0};f.f.j=(t,r)=>{var n=f.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var u=new Promise((r,u)=>n=e[t]=[r,u])
;r.push(n[2]=u);var i=f.p+f.u(t),s=new Error;f.l(i,r=>{if(f.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var u=r&&("load"===r.type?"missing":r.type),i=r&&r.target&&r.target.src
;s.message="Loading chunk "+t+" failed.\n("+u+": "+i+")",s.name="ChunkLoadError",s.type=u,s.request=i,n[1](s)}},"chunk-"+t,t)}};var t=(t,r)=>{var n,u,[i,s,o]=r,a=0;if(i.some(t=>0!==e[t])){
for(n in s)f.o(s,n)&&(f.m[n]=s[n]);if(o)o(f)}for(t&&t(r);a<i.length;a++)u=i[a],f.o(e,u)&&e[u]&&e[u][0](),e[u]=0
},r=this.__webpack_jsonp_uu_shoppinglist_maing02_hi_0_1_0_index=this.__webpack_jsonp_uu_shoppinglist_maing02_hi_0_1_0_index||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),f(533)
})());