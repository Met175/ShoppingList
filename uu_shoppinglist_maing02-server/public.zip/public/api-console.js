/*!  */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements")):"function"==typeof define&&define.amd?define("api-console",["module","uu5g05","uu_plus4u5g02","uu_plus4u5g02-app","uu_plus4u5g02-elements"],t):"object"==typeof exports?exports["api-console"]=t(require("module"),require("uu5g05"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements")):e["api-console"]=t(e[void 0],e.uu5g05,e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"])
}(this,(e,t,r,u,n)=>(()=>{var o={779:(e,t,r)=>{"use strict";r.r(t),r.d(t,{render:()=>c});var u=r(606),n=r(410),o=r.n(n),i=r(486),s=r.n(i),p=r(254),l=r.n(p),a=r(266)
;if(u.Environment.appVersion="0.1.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}
function c(e){u.Utils.Dom.render((0,a.jsx)(o().SpaProvider,{initialLanguageList:["en","cs"],skipAppWorkspaceProvider:!0,children:(0,a.jsx)(o().RouteDataProvider,{children:(0,a.jsx)(s().Spa,{
children:(0,a.jsx)(s().RouteController,{children:(0,a.jsx)(l().RouteContainer,{header:"uuShoppinglistMaing02 apiConsole",children:(0,a.jsx)(u.DynamicLibraryComponent,{
uu5Tag:"UuConsoleCommandLine.ApiClient",loadStrategy:"apiConsole"})})})})})}),document.getElementById(e))}},557:(e,t,r)=>{
var u=r(28),n="undefined"!=typeof document,o=((u?u.uri:n&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),i="/0.0.0/"
;(o=o.split(/\//).slice(0,-1).join("/")+"/").substr(-i.length)!==i&&(i="/0.x/"),o.substr(-i.length)===i&&(o=o.substr(0,o.length-i.length)+"/0.1.0/"),r.p=o,e.exports=r(779);var s=e.exports
;s&&"object"==typeof s&&("version"in s||Object.defineProperty(s,"version",{configurable:!0,value:"0.1.0"}),"name"in s||Object.defineProperty(s,"name",{configurable:!0,
value:"uu_shoppinglist_maing02-hi".split(/[\/\\]/).pop()}),"namespace"in s||Object.defineProperty(s,"namespace",{configurable:!0,value:"UuShoppinglist"}))},266:(e,t,r)=>{
const u=r(606),n=u._jsxJsxRuntime;if(n)Object.assign(t,n);else{let e=u.Utils.Element.create;t.Fragment=u.Fragment,t.jsx=function(t,r,u){let n=void 0!==r.key?r.key:u;return e(t,n!==r.key?{...r,key:n
}:r)},t.jsxs=function(t,r,u){let{children:n,...o}=r,i=void 0!==r.key?r.key:u;return e(t,i!==r.key?{...o,key:u}:o,...n)}}},28:t=>{"use strict";t.exports=e},606:e=>{"use strict";e.exports=t},410:e=>{
"use strict";e.exports=r},486:e=>{"use strict";e.exports=u},254:e=>{"use strict";e.exports=n}},i={};function s(e){var t=i[e];if(void 0!==t)return t.exports;var r=i[e]={exports:{}}
;return o[e](r,r.exports,s),r.exports}return s.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return s.d(t,{a:t}),t},s.d=(e,t)=>{for(var r in t)s.o(t,r)&&!s.o(e,r)&&Object.defineProperty(e,r,{
enumerable:!0,get:t[r]})},s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),s.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
Object.defineProperty(e,"__esModule",{value:!0})},s.p="",s(557)})());